const Pool = require('pg').Pool
const pool = new Pool({
  user: 'Me',
  host: 'localhost',
  database: 'api',
  password: 'kedareto',
  port: 5432,
})
const getProducts = (request, response) => {
  pool.query('SELECT * FROM productos', (error, results) => {
    if (error) {
       response.json({ info: 'Error' })
    }
    else{
    	response.status(200).json(results.rows)
	}
  })
}
const getProductsById = (request, response) => {
  const id = parseInt(request.params.id)

  pool.query('SELECT * FROM productos WHERE idAlimento = $1', [id], (error, results) => {
    if (error) {
       response.json({ info: 'Error' })
    }
    else{
    	response.status(200).json(results.rows)
	}
  })
}
const createProduct = (request, response) => {
  const { id, name, image, quantity, date } = request.body

  pool.query('INSERT INTO productos VALUES ($1, $2, $3, $4, $5)',
   [id,name,image,quantity,date],
    (error, results) => {
    if (error) {
       response.json({ info: 'Error' })
    }
    else{
    	response.status(201).send(`Product added correctly`)
    }
  })
}
const updateProduct = (request, response) => {
  const id = parseInt(request.params.id)
  const { name, image, quantity, date } = request.body

  pool.query(
    'UPDATE productos SET nombre = $1, foto = $2, cantidad = $3, fechaCaducidad = $4 WHERE idAlimento = $5',
    [name, image, quantity, date, id],
    (error, results) => {
    if (error) {
       response.json({ info: 'Error' })
    }
    else{
      response.status(200).send(`Product modified with ID: ${id}`)
  	}
    }
  )
}
const deleteProduct = (request, response) => {
  const id = parseInt(request.params.id)

  pool.query('DELETE FROM productos WHERE idAlimento = $1', 
  	[id], 
  	(error, results) => {
    if (error) {
       response.json({ info: 'Error' })
    }
    else{
    	response.status(200).send(`Product deleted with ID: ${id}`)
    }
  })
}
module.exports = {
  getProducts,
  getProductsById,
  createProduct,
  updateProduct,
  deleteProduct,
}