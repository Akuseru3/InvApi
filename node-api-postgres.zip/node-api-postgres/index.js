const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const db = require('./queries')
const port = 3000

app.use(bodyParser.json())
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
)
app.get('/', (request, response) => {
  response.json({ info: 'Node.js, Express, and Postgres API' })
})

app.get('/productos', db.getProducts)
app.get('/productos/:id', db.getProductsById)
app.post('/productos', db.createProduct)
app.put('/productos/:id', db.updateProduct)
app.delete('/productos/:id', db.deleteProduct)

app.listen(port, () => {
  console.log(`App running on port ${port}.`)
})